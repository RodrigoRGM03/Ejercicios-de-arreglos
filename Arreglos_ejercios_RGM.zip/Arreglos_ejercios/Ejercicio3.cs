using System;

class Ejercicio3
{
    public static void PromedioPesos()
    {
        
        double[] pesos = new double[10];
        double sumaPesos = 0;

       
        Console.WriteLine("Ingrese el peso de 10 personas:");
        for (int i = 0; i < pesos.Length; i++)
        {
            Console.Write($"Persona {i + 1}: ");
            pesos[i] = double.Parse(Console.ReadLine());
            sumaPesos += pesos[i]; 
        }

       
        double promedio = sumaPesos / pesos.Length;
        Console.WriteLine($"\nEl promedio de los pesos es: {promedio}");

        
        int porEncimaDelPromedio = 0;
        int porDebajoDelPromedio = 0;

        foreach (double peso in pesos)
        {
            if (peso > promedio)
            {
                porEncimaDelPromedio++;
            }
            else if (peso < promedio)
            {
                porDebajoDelPromedio++;
            }
        }

   
        Console.WriteLine($"Personas con peso por encima del promedio: {porEncimaDelPromedio}");
        Console.WriteLine($"Personas con peso por debajo del promedio: {porDebajoDelPromedio}");
    }
}
