using System;

class Ejercicio1
{
    public static void InvertirArreglo()
    {
        int[] arreglo = { 1, 2, 3, 4, 5 };
        int n = arreglo.Length;

        for (int i = 0; i < n / 2; i++)
        {
            int temp = arreglo[i];
            arreglo[i] = arreglo[n - 1 - i];
            arreglo[n - 1 - i] = temp;
        }

        Console.WriteLine("Arreglo invertido:");
        foreach (int i in arreglo)
        {
            Console.Write(i + " ");
        }
        Console.WriteLine();
    }
}
