using System;

class Ejercicio2
{
    public static void BuscarElemento()
    {
        int[,] matriz = {
            { 1, 2, 3 },
            { 4, 5, 6 },
            { 7, 8, 9 }
        };

        Console.Write("Ingrese el valor a buscar: ");
        int valorBuscado = int.Parse(Console.ReadLine());
        bool encontrado = false;

        foreach (int elemento in matriz)
        {
            if (elemento == valorBuscado)
            {
                encontrado = true;
                break;
            }
        }

        if (encontrado)
        {
            Console.WriteLine($"El valor {valorBuscado} existe en el arreglo.");
        }
        else
        {
            Console.WriteLine($"El valor {valorBuscado} no existe en el arreglo.");
        }
    }
}
