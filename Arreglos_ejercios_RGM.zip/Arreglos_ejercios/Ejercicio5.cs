using System;

class Ejercicio5
{
    public static void SueldosAcumulados()
    {
        string[] empleados = new string[5];
        double[,] sueldos = new double[5, 10]; 
        
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"Ingrese el nombre del empleado {i + 1}:");
            empleados[i] = Console.ReadLine();

            Console.WriteLine($"Ingrese los sueldos quincenales para los últimos 10 meses para {empleados[i]}:");
            for (int j = 0; j < 10; j++) 
            {
                Console.Write($"Quincena {j + 1}: ");
                sueldos[i, j] = double.Parse(Console.ReadLine());
            }
        }

        // Calcular sueldo acumulado de los últimos 10 meses
        double[] acumulado = new double[5];
        double totalPagado = 0;
        string empleadoMayorIngreso = "";
        double mayorIngreso = 0;

        for (int i = 0; i < 5; i++)
        {
            double suma = 0;
            for (int j = 0; j < 10; j++) 
            {
                suma += sueldos[i, j];
            }
            acumulado[i] = suma;
            totalPagado += suma;

            if (suma > mayorIngreso)
            {
                mayorIngreso = suma;
                empleadoMayorIngreso = empleados[i];
            }
        }

        
        Console.WriteLine($"\nTotal pagado en sueldos a todos los empleados: {totalPagado}");
        Console.WriteLine($"Empleado con el mayor ingreso acumulado: {empleadoMayorIngreso} con un total de: {mayorIngreso}");
    }
}
