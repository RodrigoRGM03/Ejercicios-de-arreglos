﻿namespace Arreglos_ejercios;

class Program
{
    static void Main(string[] args)
    {
                int opcion = 0;
            do
            {
                Console.Clear();
                Console.WriteLine("============================");
                Console.WriteLine("==== Menú de Ejercicios ====");
                Console.WriteLine("1. Invertir un arreglo unidimensional");
                Console.WriteLine("2. Buscar en un arreglo bidimensional");
                Console.WriteLine("3. Promedio de pesos");
                Console.WriteLine("4. Promedio de notas por curso");
                Console.WriteLine("5. Sueldos acumulados");
                Console.WriteLine("6. Salir");

                
                bool entradaValida = false;
                while (!entradaValida)
                {
                    Console.Write("Seleccione una opción: ");
                    string entrada = Console.ReadLine();

                    try
                    {
                        opcion = int.Parse(entrada);
                        if (opcion < 1 || opcion > 6)
                        {
                            Console.WriteLine("Por favor, seleccione una opción entre 1 y 6.");
                        }
                        else
                        {
                            entradaValida = true;
                        }
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Entrada inválida. Por favor, ingrese un número.");
                    }
                }

                switch (opcion)
                {
                    case 1:
                        Ejercicio1.InvertirArreglo();
                        break;
                    case 2:
                        Ejercicio2.BuscarElemento();
                        break;
                    case 3:
                        Ejercicio3.PromedioPesos();
                        break;
                    case 4:
                        Ejercicio4.PromedioNotasPorCurso();
                        break;
                    case 5:
                        Ejercicio5.SueldosAcumulados();
                        break;
                    case 6:
                        Console.WriteLine("Saliendo...");
                        break;
                }

                if (opcion != 6)
                {
                    Console.WriteLine("Presione una tecla para continuar...");
                    Console.ReadKey();
                }

            } while (opcion != 6);

    }
}
