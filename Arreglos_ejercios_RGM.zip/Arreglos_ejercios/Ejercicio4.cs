using System;

class Ejercicio4
{
    public static void PromedioNotasPorCurso()
    {
        double[,] notas = {
            { 70, 80, 90, 85, 88 }, 
            { 60, 75, 78, 82, 69 }, 
            { 85, 90, 88, 92, 91 }, 
            { 65, 72, 70, 68, 71 },  
            { 88, 86, 85, 90, 87 }   
        };

        string[] cursos = { "Estructura de Datos", "Desarrollo de Aplicaciones", "Ingeniería de Software",
                            "Administración de Base de Datos", "Inglés IV" };

        double mayorPromedio = 0;
        string cursoMayorPromedio = "";

        for (int i = 0; i < notas.GetLength(0); i++)
        {
            double suma = 0;
            for (int j = 0; j < notas.GetLength(1); j++)
            {
                suma += notas[i, j];
            }
            double promedio = suma / notas.GetLength(1);

            if (promedio > mayorPromedio)
            {
                mayorPromedio = promedio;
                cursoMayorPromedio = cursos[i];
            }
        }

        Console.WriteLine($"El curso con el mayor promedio general es: {cursoMayorPromedio}");
    }
}
